import { 
  SkillCategory, 
  Project, 
  Experience, 
  Education, 
  Certification, 
  Achievement, 
  Service, 
  Testimonial 
} from './types';

export const PERSONAL_INFO = {
  name: "Tikendrajit Sarmah",
  title: "Creative Full Stack Developer",
  roles: ["Full-Stack Engineer", "UI/UX Designer", "Software Architect", "Creative Technologist"],
  bio: "I am a creative full-stack engineer dedicated to crafting premium, fast, and highly-polished digital products. By bridging the gap between rigorous back-end architecture and delightful visual design, I build web experiences that leave a lasting impression.",
  story: "With a deep love for both the logical complexities of modern backend engineering and the visual aesthetics of fine-crafted user interfaces, I have spent the last 5+ years building software that doesn't just work—it delights. I focus on pixel-perfect layouts, fluid micro-animations, and high-performance, scalable codebases.",
  objective: "To design and engineer exceptional, accessible digital products that merge state-of-the-art tech with clean, human-centered designs for world-class clients and teams.",
  avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=600&h=600", // High-quality profile photo
  email: "tikendrajitsarmah386@gmail.com",
  phone: "9387192132",
  location: "Mangaldai",
  whatsappUrl: "https://wa.me/919387192132",
  linkedinUrl: "https://linkedin.com",
  githubUrl: "https://github.com",
  instagramUrl: "https://instagram.com",
  resumeUrl: "#"
};

export const FUN_FACTS = [
  "☕ Powered by specialty espresso and dark chocolate.",
  "💻 Passionate open-source contributor and lifetime learner.",
  "🎨 Hobbyist digital painter and 3D modeller in Blender.",
  "🏔️ Loves alpine hiking, backcountry camping, and capturing nature."
];

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    title: "Core Technologies",
    skills: [
      { name: "HTML", level: 95, iconName: "Code2" },
      { name: "CSS", level: 90, iconName: "Palette" },
      { name: "PYTHON", level: 85, iconName: "Terminal" }
    ]
  }
];

export const PROJECTS: Project[] = [
  {
    id: "proj-1",
    title: "Linear-Style Task Management",
    description: "A premium, keyboard-shortcut-driven project management app featuring beautiful dark grids, lightning-fast search, and multi-user sync.",
    longDescription: "Inspired by the sleekness of Linear.app, this project management tool offers an ultra-responsive interface with dark and light mode optimization. It implements local-first optimistic state updates, complex shortcut systems, filter chains, and real-time syncing utilizing web sockets. Includes interactive burndown charts and board drag-and-drop mechanics.",
    technologies: ["React", "TypeScript", "Tailwind CSS", "Zustand", "Framer Motion", "D3.js"],
    imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800&h=500",
    liveUrl: "https://example.com",
    githubUrl: "https://github.com",
    featured: true,
    category: "fullstack"
  },
  {
    id: "proj-2",
    title: "Apex Finance Analytics Dashboard",
    description: "An elegant, interactive banking dashboard with high-fidelity charts, automated budgeting, and AI financial summaries.",
    longDescription: "A gorgeous modern financial dashboard with glassmorphism layouts. Uses Recharts and D3 to map transaction histories, portfolio returns, and predictive expenses. Users can plug in standard banking API credentials, check real-time market data, convert currencies, and download elegant PDF expense summaries.",
    technologies: ["React", "TypeScript", "Tailwind CSS", "Recharts", "Express", "PostgreSQL"],
    imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800&h=500",
    liveUrl: "https://example.com",
    githubUrl: "https://github.com",
    featured: true,
    category: "fullstack"
  },
  {
    id: "proj-3",
    title: "Aura Creative Studio Platform",
    description: "A gorgeous interactive spatial portfolio platform built for creative design agencies to highlight video, 3D assets, and responsive copy.",
    longDescription: "A beautiful frontend web experience focused on brand strategy and visual hierarchy. Includes customized scroll-triggered animations via Framer Motion, dynamic cursor distortions, magnetic buttons, custom sliders, and a complete content management system integration.",
    technologies: ["React", "Next.js", "Framer Motion", "Tailwind CSS", "Figma"],
    imageUrl: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&q=80&w=800&h=500",
    liveUrl: "https://example.com",
    githubUrl: "https://github.com",
    featured: true,
    category: "frontend"
  },
  {
    id: "proj-4",
    title: "Zenith E-Commerce Core",
    description: "A blazing-fast serverless commerce framework supporting custom cart rules, high-converting checkout flows, and Stripe integration.",
    longDescription: "An ultra-performant e-commerce framework optimized for absolute speed and conversion. Incorporates lazy-loading, automatic image optimization pipelines, dynamic stock counts via Redis cache, clean invoice generation, and custom merchant control panels.",
    technologies: ["React", "TypeScript", "Node.js", "Redis", "Stripe", "Tailwind CSS"],
    imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800&h=500",
    liveUrl: "https://example.com",
    githubUrl: "https://github.com",
    featured: false,
    category: "backend"
  }
];

export const EXPERIENCE_HISTORY: Experience[] = [
  {
    id: "exp-1",
    role: "Senior Full Stack Engineer",
    company: "Stripe-inspired FinTech Corp",
    location: "San Francisco, CA (Hybrid)",
    period: "2024 - Present",
    description: [
      "Architected and deployed premium web dashboards improving client configuration speeds by 40%.",
      "Pioneered standard internal component libraries styled with Tailwind and Framer Motion for high-fidelity interactive elements.",
      "Optimized database indexing and caching strategy in PostgreSQL, reducing average API response time from 350ms to 92ms.",
      "Mentored 6 junior engineers on best practices regarding type safety, clean code patterns, and web accessibility (a11y)."
    ],
    current: true
  },
  {
    id: "exp-2",
    role: "Full Stack Developer",
    company: "PixelCraft Design Agency",
    location: "Remote",
    period: "2022 - 2024",
    description: [
      "Engineered gorgeous interactive websites for Fortune 500 tech clients, utilizing custom CSS-in-JS, GSAP, and advanced React structures.",
      "Built resilient Node.js REST and GraphQL API gateways managing high-throughput data pipelines with Redis caching.",
      "Introduced responsive design QA checklist that reduced mobile layout bug tickets by 70%.",
      "Collaborated closely with lead UI designers in Figma to refine wireframes into pixel-perfect Tailwind markup."
    ],
    current: false
  },
  {
    id: "exp-3",
    role: "Software Developer Intern",
    company: "Synergy Cloud Labs",
    location: "Seattle, WA",
    period: "2021 - 2022",
    description: [
      "Assisted in developing cloud orchestration tools using Node.js and AWS Lambda functions.",
      "Wrote robust unit and integration tests using Jest and React Testing Library, boosting coverage from 55% to 85%.",
      "Implemented beautiful light/dark mode UI modules and modular settings menus."
    ],
    current: false
  }
];

export const EDUCATION_HISTORY: Education[] = [
  {
    id: "edu-1",
    degree: "Bachelor of Computer Application (BCA)",
    institution: "Mangaldai College",
    location: "Mangaldai, Assam",
    period: "Completed",
    description: "Core curriculum focused on Software Engineering, Databases, Web Technologies, and Python programming."
  },
  {
    id: "edu-2",
    degree: "Higher Secondary (HS)",
    institution: "Private Institute",
    location: "Assam",
    period: "Completed",
    description: "Concentration in science stream with focus on Computer Science and Mathematics."
  },
  {
    id: "edu-3",
    degree: "High School Leaving Certificate (HSLC)",
    institution: "Dighirpar High School",
    location: "Dighirpar, Assam",
    period: "Completed",
    description: "Completed general secondary education with standard sciences, mathematics, and languages."
  }
];

export const CERTIFICATIONS: Certification[] = [
  {
    id: "cert-1",
    title: "AWS Certified Solutions Architect – Professional",
    issuer: "Amazon Web Services (AWS)",
    issueDate: "2025",
    credentialId: "AWS-SAP-982"
  },
  {
    id: "cert-2",
    title: "Google UX Design Professional Certificate",
    issuer: "Google / Coursera",
    issueDate: "2023",
    credentialId: "G-UXD-3810"
  },
  {
    id: "cert-3",
    title: "Advanced React & State Architecture",
    issuer: "Frontend Masters",
    issueDate: "2022",
    credentialId: "FM-REACT-98"
  }
];

export const ACHIEVEMENTS: Achievement[] = [
  { id: "ach-1", value: "5+", label: "Years Experience" },
  { id: "ach-2", value: "30+", label: "Premium Projects Deployed" },
  { id: "ach-3", value: "99.9%", label: "Uptime Achieved" },
  { id: "ach-4", value: "40k+", label: "GitHub Stars Generated" }
];

export const SERVICES: Service[] = [
  {
    id: "srv-1",
    title: "Web Application Development",
    description: "End-to-end engineering of responsive, highly interactive web applications built with React/Next.js and secure Express backend services.",
    iconName: "Laptop",
    features: ["Server-side rendering (SSR)", "Global state management", "SEO optimized structure", "API route proxy and integrations"]
  },
  {
    id: "srv-2",
    title: "UI/UX & Brand Design",
    description: "Creative digital experience design mapping user personas, wireframes, and production-ready high-fidelity Figma components.",
    iconName: "Figma",
    features: ["Design system development", "Interactive visual prototypes", "Micro-interaction models", "Aesthetics & styling guidelines"]
  },
  {
    id: "srv-3",
    title: "Backend & System Design",
    description: "Robust, bulletproof APIs and cloud architectures designed with Node.js, Express, databases, and Docker-driven orchestration.",
    iconName: "Server",
    features: ["REST & GraphQL gateway design", "Optimized DB querying", "Redis caching patterns", "Cloud Run & AWS deployment setup"]
  },
  {
    id: "srv-4",
    title: "High-Performance Optimization",
    description: "Transform lagging codebases into 100/100 Lighthouse performance-scoring products with fluid motion guidelines.",
    iconName: "Zap",
    features: ["Image pipeline compression", "Bundle tree-shaking & code splitting", "Optimistic state engines", "Asset lazy-loading standards"]
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "test-1",
    name: "Sarah Jenkins",
    role: "VP of Product",
    company: "Aura Analytics",
    avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150&h=150",
    content: "Working with Tikendrajit was an absolute game-changer. He has the rare capability of creating beautiful interfaces while writing clean, solid, enterprise-ready backend architecture. Our users are consistently blown away by the speed and animations.",
    rating: 5
  },
  {
    id: "test-2",
    name: "Marcus Aurelius",
    role: "Lead Creative Director",
    company: "Neo-Vision Studio",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150&h=150",
    content: "His attention to visual details, subtle margins, transition speeds, and typography was unmatched. He transformed our complex agency Figma files into a production-ready website with flawless micro-interactions. Simply brilliant.",
    rating: 5
  },
  {
    id: "test-3",
    name: "Clara Zhang",
    role: "Founder & CEO",
    company: "Z-Finance Labs",
    avatarUrl: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=150&h=150",
    content: "Tikendrajit built our dashboard core under a tight deadline. The codebase is incredibly easy to read, uses type safety impeccably, and loading times are practically instantaneous. I'd hire him again in a heartbeat.",
    rating: 5
  }
];
