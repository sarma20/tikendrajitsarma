import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Star, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../data';

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0); // -1 for left, 1 for right
  const [isAutoplay, setIsAutoplay] = useState(true);

  // Auto scroll testimonials
  useEffect(() => {
    if (!isAutoplay) return;
    const interval = setInterval(() => {
      setDirection(1);
      setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 6000); // cycle every 6s

    return () => clearInterval(interval);
  }, [isAutoplay]);

  const handleNext = () => {
    setIsAutoplay(false);
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
  };

  const handlePrev = () => {
    setIsAutoplay(false);
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  };

  // Slide Animation Variants
  const slideVariants = {
    enter: (dir: number) => ({
      x: dir > 0 ? 100 : -100,
      opacity: 0,
    }),
    center: {
      x: 0,
      opacity: 1,
    },
    exit: (dir: number) => ({
      x: dir > 0 ? -100 : 100,
      opacity: 0,
    }),
  };

  const activeTestimonial = TESTIMONIALS[currentIndex];

  return (
    <section 
      id="testimonials" 
      className="py-24 px-6 relative overflow-hidden bg-slate-50/50 dark:bg-slate-900/35 border-y border-slate-100 dark:border-slate-800/50"
    >
      <div className="max-w-4xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-16">
          <h2 className="font-mono text-xs font-semibold tracking-widest text-violet-600 dark:text-violet-400 uppercase mb-3">
            06 / Testimonials
          </h2>
          <p className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white">
            Client success stories
          </p>
          <div className="w-12 h-[2px] bg-gradient-to-r from-violet-600 to-blue-500 mt-4 rounded-full" />
        </div>

        {/* Carousel Container */}
        <div 
          className="relative min-h-[280px] sm:min-h-[220px]"
          onMouseEnter={() => setIsAutoplay(false)}
          onMouseLeave={() => setIsAutoplay(true)}
        >
          {/* Quote Mark visual flair */}
          <div className="absolute top-0 left-6 text-violet-500/10 pointer-events-none">
            <Quote size={80} />
          </div>

          <AnimatePresence initial={false} custom={direction} mode="wait">
            <motion.div
              key={currentIndex}
              custom={direction}
              variants={slideVariants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ duration: 0.4, ease: 'easeInOut' }}
              className="glass-card p-8 sm:p-10 rounded-3xl relative z-10 flex flex-col gap-6"
            >
              {/* Stars Row */}
              <div className="flex items-center gap-1">
                {[...Array(activeTestimonial.rating)].map((_, i) => (
                  <Star key={i} size={14} className="fill-amber-400 text-amber-400" />
                ))}
              </div>

              {/* Text review block */}
              <blockquote className="text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed italic font-light">
                "{activeTestimonial.content}"
              </blockquote>

              {/* Author Info */}
              <div className="flex items-center gap-4 border-t border-slate-100 dark:border-slate-800/60 pt-6">
                <img
                  src={activeTestimonial.avatarUrl}
                  alt={activeTestimonial.name}
                  className="w-12 h-12 rounded-full object-cover border border-slate-200/50 dark:border-slate-800/50"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <cite className="not-italic font-display text-sm font-bold text-slate-900 dark:text-white">
                    {activeTestimonial.name}
                  </cite>
                  <p className="text-[10px] font-mono text-slate-400 dark:text-slate-500">
                    {activeTestimonial.role} at <span className="font-semibold text-slate-500 dark:text-slate-400">{activeTestimonial.company}</span>
                  </p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Sliders navigation controllers */}
        <div className="flex items-center justify-between mt-8 relative z-10">
          {/* Progress Indicators */}
          <div className="flex items-center gap-2">
            {TESTIMONIALS.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setDirection(idx > currentIndex ? 1 : -1);
                  setCurrentIndex(idx);
                  setIsAutoplay(false);
                }}
                className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                  idx === currentIndex ? 'w-6 bg-violet-600' : 'w-1.5 bg-slate-200 dark:bg-slate-800'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>

          {/* Button controllers */}
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrev}
              className="p-3 rounded-full bg-white dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors cursor-pointer shadow-xs"
              aria-label="Previous testimonial"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={handleNext}
              className="p-3 rounded-full bg-white dark:bg-slate-900 border border-slate-200/40 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-violet-600 dark:hover:text-violet-400 transition-colors cursor-pointer shadow-xs"
              aria-label="Next testimonial"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
}
