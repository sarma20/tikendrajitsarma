import { motion } from 'motion/react';
import { Briefcase, GraduationCap, Award, Calendar, MapPin, ExternalLink, CheckCircle2 } from 'lucide-react';
import { EXPERIENCE_HISTORY, EDUCATION_HISTORY, CERTIFICATIONS } from '../data';

export default function ExperienceAndEducation() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.12 },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, x: -15 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { type: 'spring', stiffness: 120, damping: 18 },
    },
  };

  return (
    <section 
      id="experience" 
      className="py-24 px-6 relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-16">
          <h2 className="font-mono text-xs font-semibold tracking-widest text-violet-600 dark:text-violet-400 uppercase mb-3">
            04 / Journey & Credentials
          </h2>
          <p className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white">
            Experience & education history
          </p>
          <div className="w-12 h-[2px] bg-gradient-to-r from-violet-600 to-blue-500 mt-4 rounded-full" />
        </div>

        {/* Multi-column grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column (7 columns): Work Experience Timeline */}
          <div className="lg:col-span-7">
            <div className="flex items-center gap-3.5 mb-8">
              <div className="p-2.5 rounded-xl bg-violet-500/10 text-violet-600 dark:text-violet-400">
                <Briefcase size={20} />
              </div>
              <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                Professional Experience
              </h3>
            </div>

            {/* Vertical timeline */}
            <motion.div 
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-100px' }}
              className="relative pl-6 border-l-2 border-slate-200/65 dark:border-slate-800 flex flex-col gap-10"
            >
              {EXPERIENCE_HISTORY.map((exp, index) => (
                <motion.div
                  variants={cardVariants}
                  key={exp.id}
                  className="relative group"
                >
                  {/* Timeline Glowing Node */}
                  <div className={`absolute -left-[31px] top-1.5 w-4 h-4 rounded-full border-2 bg-white dark:bg-slate-900 transition-colors duration-300 ${
                    exp.current 
                      ? 'border-violet-600 scale-110 shadow-sm shadow-violet-500/40' 
                      : 'border-slate-300 dark:border-slate-700 group-hover:border-violet-500'
                  }`} />

                  {/* Context block */}
                  <div className="glass-card p-6 rounded-2xl relative transition-all group-hover:shadow-md">
                    {/* Role title & Date bar */}
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-3.5">
                      <div>
                        <h4 className="font-display text-sm sm:text-base font-bold text-slate-900 dark:text-white group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">
                          {exp.role}
                        </h4>
                        <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                          {exp.company}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 text-[10px] font-mono text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-800/80 px-2.5 py-1 rounded-md">
                        <Calendar size={11} />
                        <span>{exp.period}</span>
                      </div>
                    </div>

                    {/* Location bar */}
                    <div className="flex items-center gap-1 text-[10px] font-mono text-slate-400 dark:text-slate-500 mb-4">
                      <MapPin size={11} />
                      <span>{exp.location}</span>
                    </div>

                    {/* Bullets */}
                    <ul className="flex flex-col gap-2">
                      {exp.description.map((bullet, idx) => (
                        <li key={idx} className="flex items-start gap-2.5 text-slate-500 dark:text-slate-400 text-xs leading-relaxed">
                          <CheckCircle2 size={12} className="text-violet-500 mt-0.5 shrink-0" />
                          <span>{bullet}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Right Column (5 columns): Education & Certifications */}
          <div className="lg:col-span-5 flex flex-col gap-10">
            
            {/* Education Sub-timeline */}
            <div>
              <div className="flex items-center gap-3.5 mb-8">
                <div className="p-2.5 rounded-xl bg-violet-500/10 text-violet-600 dark:text-violet-400">
                  <GraduationCap size={20} />
                </div>
                <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                  Academic History
                </h3>
              </div>

              <motion.div 
                variants={containerVariants}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: '-100px' }}
                className="relative pl-6 border-l-2 border-slate-200/65 dark:border-slate-800 flex flex-col gap-8"
              >
                {EDUCATION_HISTORY.map((edu) => (
                  <motion.div
                    variants={cardVariants}
                    key={edu.id}
                    className="relative group"
                  >
                    {/* Node */}
                    <div className="absolute -left-[31px] top-1.5 w-4 h-4 rounded-full border-2 border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 group-hover:border-violet-500 transition-colors" />

                    <div className="glass-card p-6 rounded-2xl relative transition-all group-hover:shadow-md">
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <h4 className="font-display text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                          {edu.degree}
                        </h4>
                        <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-800/80 px-2 py-0.5 rounded">
                          {edu.period}
                        </span>
                      </div>
                      <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                        {edu.institution}
                      </p>
                      <p className="text-slate-500 dark:text-slate-400 text-[11px] leading-relaxed">
                        {edu.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </div>

            {/* Certifications cards list */}
            <div>
              <div className="flex items-center gap-3.5 mb-6">
                <div className="p-2.5 rounded-xl bg-violet-500/10 text-violet-600 dark:text-violet-400">
                  <Award size={20} />
                </div>
                <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                  Certifications
                </h3>
              </div>

              <div className="flex flex-col gap-4">
                {CERTIFICATIONS.map((cert, idx) => (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ type: 'spring', stiffness: 200, delay: idx * 0.1 }}
                    key={cert.id}
                    className="group glass-card p-4 rounded-2xl flex items-center justify-between hover:border-violet-500/20 dark:hover:border-violet-500/10"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800/70 text-slate-500 dark:text-slate-400 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-all">
                        <Award size={18} />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">
                          {cert.title}
                        </h4>
                        <p className="text-[10px] text-slate-400 dark:text-slate-500">
                          {cert.issuer} • {cert.issueDate}
                        </p>
                      </div>
                    </div>

                    <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200/40 dark:border-slate-700/40 text-[10px] font-mono text-slate-500 dark:text-slate-400">
                      {cert.credentialId}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
