import { useEffect, useState } from 'react';
import { motion, useMotionValue, useSpring } from 'motion/react';

export default function BackgroundEffects() {
  const [mounted, setMounted] = useState(false);
  
  // Mouse coordinates using motion values for performant 60 FPS cursor tracking
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  
  // Smooth spring physics for a high-quality mouse following feel
  const springX = useSpring(mouseX, { damping: 40, stiffness: 200, mass: 0.5 });
  const springY = useSpring(mouseY, { damping: 40, stiffness: 200, mass: 0.5 });

  useEffect(() => {
    setMounted(true);
    
    const handleMouseMove = (e: MouseEvent) => {
      mouseX.set(e.clientX - 250); // Offset to center the 500px glow circle
      mouseY.set(e.clientY - 250);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [mouseX, mouseY]);

  if (!mounted) return null;

  return (
    <div className="fixed inset-0 -z-50 overflow-hidden pointer-events-none">
      {/* Interactive mouse follow glow spotlight */}
      <motion.div
        className="hidden lg:block absolute w-[500px] h-[500px] rounded-full opacity-40 dark:opacity-20 blur-[120px] mix-blend-screen dark:mix-blend-lighten"
        style={{
          x: springX,
          y: springY,
          background: 'radial-gradient(circle, rgba(139,92,246,0.3) 0%, rgba(59,130,246,0.2) 50%, rgba(0,0,0,0) 100%)',
        }}
      />

      {/* Floating Ambient Blob Left (Purple-indigo) */}
      <motion.div
        className="absolute -top-[10%] -left-[5%] w-[40vw] h-[40vw] rounded-full bg-violet-300/20 dark:bg-violet-900/10 blur-[80px] md:blur-[120px] animate-pulse-slow"
        initial={{ opacity: 0.5 }}
        animate={{
          x: [0, 30, -20, 0],
          y: [0, -50, 20, 0],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Floating Ambient Blob Right (Blue-cyan) */}
      <motion.div
        className="absolute top-[30%] -right-[10%] w-[35vw] h-[35vw] rounded-full bg-blue-300/15 dark:bg-blue-950/10 blur-[100px] md:blur-[150px]"
        animate={{
          x: [0, -40, 20, 0],
          y: [0, 60, -30, 0],
        }}
        transition={{
          duration: 30,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Floating Ambient Blob Center Bottom (Indigo-pink) */}
      <motion.div
        className="absolute bottom-[-10%] left-[20%] w-[45vw] h-[45vw] rounded-full bg-fuchsia-200/10 dark:bg-fuchsia-950/5 blur-[90px] md:blur-[140px]"
        animate={{
          x: [0, 50, -30, 0],
          y: [0, -40, 40, 0],
        }}
        transition={{
          duration: 28,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* High-fidelity Technical Dot Grid Overlay */}
      <div 
        className="absolute inset-0 opacity-[0.25] dark:opacity-[0.12]"
        style={{
          backgroundImage: `radial-gradient(#1e293b 1px, transparent 1px)`,
          backgroundSize: '24px 24px',
        }}
      />
    </div>
  );
}
