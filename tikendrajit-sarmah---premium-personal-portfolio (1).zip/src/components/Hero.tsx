import React, { useState, useEffect } from 'react';
import { motion, useMotionValue, useTransform } from 'motion/react';
import { ArrowRight, FileDown, Mail, Code, Terminal, Sparkles, MessageCircle } from 'lucide-react';
import { PERSONAL_INFO } from '../data';

export default function Hero() {
  const [roleIndex, setRoleIndex] = useState(0);
  const [currentText, setCurrentText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [typingSpeed, setTypingSpeed] = useState(100);

  // typing effect for roles array
  useEffect(() => {
    let timer: NodeJS.Timeout;
    const fullText = PERSONAL_INFO.roles[roleIndex];

    const handleType = () => {
      if (!isDeleting) {
        // typing text
        setCurrentText(fullText.substring(0, currentText.length + 1));
        setTypingSpeed(75);

        if (currentText === fullText) {
          // Pause at end of typing
          timer = setTimeout(() => setIsDeleting(true), 2500);
          return;
        }
      } else {
        // deleting text
        setCurrentText(fullText.substring(0, currentText.length - 1));
        setTypingSpeed(40);

        if (currentText === '') {
          setIsDeleting(false);
          setRoleIndex((prev) => (prev + 1) % PERSONAL_INFO.roles.length);
          return;
        }
      }

      timer = setTimeout(handleType, typingSpeed);
    };

    timer = setTimeout(handleType, typingSpeed);
    return () => clearTimeout(timer);
  }, [currentText, isDeleting, roleIndex, typingSpeed]);

  // Mouse tilt variables for 3D parallax effect on the avatar frame
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const rotateX = useTransform(y, [-300, 300], [15, -15]);
  const rotateY = useTransform(x, [-300, 300], [-15, 15]);

  function handleMouse(event: React.MouseEvent<HTMLDivElement, MouseEvent>) {
    const rect = event.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = event.clientX - rect.left - width / 2;
    const mouseY = event.clientY - rect.top - height / 2;
    x.set(mouseX);
    y.set(mouseY);
  }

  function handleMouseLeave() {
    x.set(0);
    y.set(0);
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 25 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: 'spring', stiffness: 100, damping: 15 },
    },
  };

  return (
    <section 
      id="home" 
      className="relative min-h-[95vh] flex items-center justify-center pt-24 pb-16 px-6 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center relative z-10">
        
        {/* Left: Text Introduction Columns */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="lg:col-span-7 flex flex-col items-start text-left"
        >
          {/* Subtle Accent Intro Badge */}
          <motion.div 
            variants={itemVariants}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/80 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 text-[#3B82F6] text-xs font-bold tracking-widest uppercase mb-6 backdrop-blur-sm"
          >
            <Sparkles size={12} className="text-[#3B82F6] animate-pulse" />
            <span>Available for Hire</span>
          </motion.div>

          <motion.h1 
            variants={itemVariants}
            className="font-display text-5xl sm:text-7xl lg:text-[84px] leading-[0.9] font-black tracking-tighter text-[#111827] dark:text-white mb-6"
          >
            CRAFTING<br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6]">
              DIGITAL
            </span><br/>
            EXPERIENCES.
          </motion.h1>

          {/* Typing Role Box */}
          <motion.div 
            variants={itemVariants}
            className="flex items-center gap-2.5 h-8 sm:h-10 text-base sm:text-lg font-mono text-slate-500 dark:text-slate-400 mb-6"
          >
            <Terminal size={16} className="text-[#3B82F6]" />
            <span className="font-semibold text-slate-800 dark:text-slate-200">
              Hi, I'm <span className="text-[#8B5CF6]">{PERSONAL_INFO.name}</span>, a {currentText}
            </span>
            <span className="w-[3px] h-5 bg-[#8B5CF6] animate-pulse" />
          </motion.div>

          <motion.p 
            variants={itemVariants}
            className="text-[#64748B] dark:text-slate-400 text-lg max-w-lg mb-10 leading-relaxed font-sans"
          >
            {PERSONAL_INFO.bio}
          </motion.p>

          {/* Action CTAs */}
          <motion.div 
            variants={itemVariants}
            className="flex flex-wrap items-center gap-4"
          >
            <a
              href="#projects"
              className="group px-8 py-4 bg-black text-white rounded-2xl font-bold flex items-center gap-2 shadow-2xl shadow-black/20 hover:bg-slate-800 dark:bg-white dark:text-black dark:hover:bg-slate-200 transition-all"
            >
              <span>View My Projects</span>
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </a>

            <a
              href="#contact"
              className="px-6 py-4 rounded-2xl bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 text-xs font-semibold tracking-wide flex items-center gap-2 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-all shadow-sm"
            >
              <Mail size={14} />
              <span>Contact Me</span>
            </a>

            <a
              href={PERSONAL_INFO.whatsappUrl}
              target="_blank"
              rel="noreferrer"
              className="px-6 py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold tracking-wide flex items-center gap-2 transition-all shadow-md shadow-emerald-500/25 dark:shadow-none"
            >
              <MessageCircle size={14} />
              <span>WhatsApp Chat</span>
            </a>

            <a
              href={PERSONAL_INFO.resumeUrl}
              className="px-6 py-4 rounded-2xl bg-white/40 backdrop-blur-md dark:bg-slate-800/50 hover:bg-slate-100/60 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-semibold tracking-wide flex items-center gap-2 transition-all border border-slate-200 dark:border-slate-800/40"
            >
              <FileDown size={14} />
              <span>Download Resume</span>
            </a>
          </motion.div>
        </motion.div>

        {/* Right: Immersive 3D Parallax Photo Frame */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: 'spring', stiffness: 50, damping: 20, delay: 0.4 }}
          className="lg:col-span-5 flex items-center justify-center"
        >
          <div 
            className="relative w-72 h-72 sm:w-96 sm:h-96 flex items-center justify-center cursor-pointer"
            onMouseMove={handleMouse}
            onMouseLeave={handleMouseLeave}
          >
            {/* Spinning Abstract Grid / Gear (Tech element) */}
            <div className="absolute inset-0 rounded-full border-2 border-dashed border-slate-200 dark:border-slate-800/80 scale-[1.12] animate-spin-slow pointer-events-none" />

            {/* Glowing background circles */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4/5 h-4/5 rounded-full bg-violet-400/10 dark:bg-violet-600/5 blur-[40px]" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 rounded-full bg-blue-400/10 dark:bg-blue-600/5 blur-[40px] delay-1000" />

            {/* Main Interactive 3D Frame */}
            <motion.div
              style={{
                rotateX: rotateX,
                rotateY: rotateY,
                transformStyle: 'preserve-3d',
              }}
              className="relative w-full h-full rounded-3xl glass border border-slate-200/50 dark:border-slate-800/50 p-4 shadow-xl"
            >
              <div 
                className="w-full h-full rounded-2xl overflow-hidden relative"
                style={{ transform: 'translateZ(30px)' }}
              >
                <img
                  src={PERSONAL_INFO.avatarUrl}
                  alt={PERSONAL_INFO.name}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual Glass overlays & grids */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent pointer-events-none" />

                {/* Micro tech details floating over avatar */}
                <div className="absolute bottom-4 left-4 right-4 glass px-3 py-2 rounded-xl border border-white/20 flex items-center justify-between pointer-events-none text-white">
                  <div className="flex items-center gap-1.5">
                    <Code size={13} className="text-violet-400" />
                    <span className="text-[10px] font-mono tracking-wider uppercase font-semibold">Active Engine</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    <span className="text-[9px] font-mono font-medium text-emerald-100">60 FPS IDEAL</span>
                  </div>
                </div>
              </div>

              {/* Float Accent Small Glass badge */}
              <motion.div
                className="absolute -top-4 -right-4 glass p-3.5 rounded-2xl shadow-lg border border-slate-200/50 dark:border-slate-800/50 flex items-center justify-center text-slate-800 dark:text-violet-400 pointer-events-none"
                style={{ transform: 'translateZ(50px)' }}
                animate={{
                  y: [0, -8, 0],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
              >
                <Code size={20} />
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Slide-down Indicator badge */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 pointer-events-none z-10 text-slate-400">
        <span className="text-[10px] font-mono tracking-widest uppercase">Scroll Down</span>
        <motion.div 
          className="w-[1.5px] h-8 bg-slate-300 dark:bg-slate-700 rounded-full overflow-hidden"
        >
          <motion.div
            className="w-full h-1/2 bg-violet-500"
            animate={{
              y: ['-100%', '200%'],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        </motion.div>
      </div>
    </section>
  );
}
