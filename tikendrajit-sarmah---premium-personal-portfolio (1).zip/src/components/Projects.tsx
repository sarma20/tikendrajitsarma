import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, Github, ZoomIn, X, Calendar, LayoutGrid, CheckCircle } from 'lucide-react';
import { PROJECTS } from '../data';
import { Project } from '../types';

export default function Projects() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeProjectModal, setActiveProjectModal] = useState<Project | null>(null);

  const categories = ['all', 'fullstack', 'frontend', 'backend'];

  const filteredProjects = selectedCategory === 'all'
    ? PROJECTS
    : PROJECTS.filter(proj => proj.category === selectedCategory);

  return (
    <section 
      id="projects" 
      className="py-24 px-6 relative overflow-hidden bg-slate-50/50 dark:bg-slate-900/35 border-y border-slate-100 dark:border-slate-800/50"
    >
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-12">
          <h2 className="font-mono text-xs font-semibold tracking-widest text-violet-600 dark:text-violet-400 uppercase mb-3">
            03 / Selected Works
          </h2>
          <p className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white">
            Premium showcase of creations
          </p>
          <div className="w-12 h-[2px] bg-gradient-to-r from-violet-600 to-blue-500 mt-4 rounded-full" />
        </div>

        {/* Categories Tab Selector */}
        <div className="flex justify-center mb-16 overflow-x-auto pb-4 max-w-full px-4 scrollbar-none">
          <div className="flex items-center gap-1.5 bg-slate-100/50 dark:bg-slate-800/40 p-1 rounded-full border border-slate-200/40 dark:border-slate-800/40 backdrop-blur-sm shrink-0">
            {categories.map((category) => {
              const isSelected = selectedCategory === category;
              return (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`relative px-5 py-2 rounded-full text-xs font-medium tracking-wide transition-all duration-200 capitalize cursor-pointer ${
                    isSelected 
                      ? 'text-slate-900 dark:text-white font-semibold shadow-xs' 
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  {isSelected && (
                    <motion.span
                      layoutId="activeProjCategoryBackground"
                      className="absolute inset-0 bg-white dark:bg-slate-900 rounded-full border border-slate-200/50 dark:border-slate-800/50 shadow-sm"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">
                    {category === 'all' ? 'All' : category === 'fullstack' ? 'Full Stack' : category}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dynamic Bento-like Grid */}
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10"
        >
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, idx) => (
              <motion.div
                layout
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ type: 'spring', stiffness: 260, damping: 25, delay: idx * 0.1 }}
                key={project.id}
                className="group relative flex flex-col bg-white dark:bg-slate-900/60 rounded-3xl border border-slate-200/50 dark:border-slate-800/50 shadow-xs hover:shadow-xl dark:hover:shadow-slate-950/40 hover:border-violet-500/25 dark:hover:border-violet-500/10 transition-all duration-300 overflow-hidden"
              >
                {/* Showcase Image container with zoom & glow triggers */}
                <div className="relative aspect-[16/10] overflow-hidden">
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent pointer-events-none" />

                  {/* Zoom click trigger overlay */}
                  <div 
                    onClick={() => setActiveProjectModal(project)}
                    className="absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer"
                  >
                    <motion.div 
                      whileHover={{ scale: 1.1 }}
                      className="p-4 rounded-full glass border border-white/40 text-white"
                    >
                      <ZoomIn size={22} />
                    </motion.div>
                  </div>

                  {/* Top-Right Category Badge */}
                  <span className="absolute top-4 right-4 px-3 py-1 rounded-full glass border border-white/20 text-white text-[10px] font-semibold uppercase tracking-wider font-mono">
                    {project.category === 'fullstack' ? 'Full Stack' : project.category}
                  </span>
                </div>

                {/* Card Context */}
                <div className="p-8 flex flex-col justify-between flex-1">
                  <div>
                    {/* Tech Badges */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.technologies.slice(0, 4).map((tech) => (
                        <span 
                          key={tech}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 border border-slate-200/30 dark:border-slate-700/30 text-[10px] font-mono"
                        >
                          {tech}
                        </span>
                      ))}
                      {project.technologies.length > 4 && (
                        <span className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 text-[10px] font-mono">
                          +{project.technologies.length - 4} more
                        </span>
                      )}
                    </div>

                    <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white mb-2.5 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed mb-6">
                      {project.description}
                    </p>
                  </div>

                  {/* Core Action Links */}
                  <div className="flex items-center justify-between mt-auto pt-4 border-t border-slate-100 dark:border-slate-800/50">
                    <button
                      onClick={() => setActiveProjectModal(project)}
                      className="text-xs font-semibold text-violet-600 dark:text-violet-400 hover:text-violet-700 flex items-center gap-1 cursor-pointer"
                    >
                      <span>Explore Project Details</span>
                    </button>

                    <div className="flex items-center gap-3">
                      <a
                        href={project.githubUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
                        aria-label="GitHub Repository"
                      >
                        <Github size={16} />
                      </a>
                      <a
                        href={project.liveUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                      >
                        <span>Live Demo</span>
                        <ExternalLink size={12} />
                      </a>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Detailed Modal popup */}
        <AnimatePresence>
          {activeProjectModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-hidden">
              {/* Dark backdrop blur */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setActiveProjectModal(null)}
                className="absolute inset-0 bg-slate-950/60 backdrop-blur-md"
              />

              {/* Modal Container */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 30 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 30 }}
                transition={{ type: 'spring', duration: 0.5 }}
                className="relative w-full max-w-4xl max-h-[90vh] bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-y-auto z-10 scrollbar-none"
              >
                {/* Close Button */}
                <button
                  onClick={() => setActiveProjectModal(null)}
                  className="absolute top-5 right-5 p-2 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-300 z-20 transition-colors cursor-pointer"
                >
                  <X size={18} />
                </button>

                {/* Hero Banner inside Modal */}
                <div className="relative aspect-[16/9] md:aspect-[21/9] w-full">
                  <img
                    src={activeProjectModal.imageUrl}
                    alt={activeProjectModal.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                  
                  {/* Category Pill */}
                  <span className="absolute top-5 left-5 px-3 py-1 rounded-full glass border border-white/20 text-white text-[10px] font-mono uppercase tracking-wider">
                    {activeProjectModal.category}
                  </span>

                  {/* Title block inside banner */}
                  <div className="absolute bottom-6 left-6 right-6 text-white">
                    <h3 className="font-display text-2xl sm:text-3xl font-bold tracking-tight mb-2">
                      {activeProjectModal.title}
                    </h3>
                    <p className="text-slate-300 text-xs sm:text-sm max-w-xl font-light">
                      {activeProjectModal.description}
                    </p>
                  </div>
                </div>

                {/* Context */}
                <div className="p-6 sm:p-10 grid grid-cols-1 md:grid-cols-12 gap-8">
                  
                  {/* Left Column (8 cols): Description & Features */}
                  <div className="md:col-span-8 flex flex-col gap-6">
                    <div>
                      <h4 className="font-display text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">
                        Project Overview
                      </h4>
                      <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                        {activeProjectModal.longDescription || activeProjectModal.description}
                      </p>
                    </div>

                    <div>
                      <h4 className="font-display text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">
                        Engineering Strengths & Specs
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                        <div className="flex items-start gap-2 text-slate-600 dark:text-slate-300 text-xs">
                          <CheckCircle size={14} className="text-emerald-500 mt-0.5 shrink-0" />
                          <span>Fully accessible and keyboard-navigable</span>
                        </div>
                        <div className="flex items-start gap-2 text-slate-600 dark:text-slate-300 text-xs">
                          <CheckCircle size={14} className="text-emerald-500 mt-0.5 shrink-0" />
                          <span>Responsive grid optimized for 4K down to mobile</span>
                        </div>
                        <div className="flex items-start gap-2 text-slate-600 dark:text-slate-300 text-xs">
                          <CheckCircle size={14} className="text-emerald-500 mt-0.5 shrink-0" />
                          <span>Strict type assertions and custom hooks</span>
                        </div>
                        <div className="flex items-start gap-2 text-slate-600 dark:text-slate-300 text-xs">
                          <CheckCircle size={14} className="text-emerald-500 mt-0.5 shrink-0" />
                          <span>Sub-100ms API server handshake latency</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right Column (4 cols): Meta details */}
                  <div className="md:col-span-4 p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/50 flex flex-col gap-6">
                    <div>
                      <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-1">
                        Timeline
                      </span>
                      <div className="flex items-center gap-2 text-xs font-semibold text-slate-800 dark:text-slate-200">
                        <Calendar size={14} className="text-violet-500" />
                        <span>Completed in 2026</span>
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-2">
                        Technologies
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {activeProjectModal.technologies.map((tech) => (
                          <span 
                            key={tech}
                            className="px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/50 text-[10px] font-mono text-slate-700 dark:text-slate-300"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="h-[1px] bg-slate-200/50 dark:bg-slate-700/50 my-1" />

                    <div className="flex flex-col gap-2">
                      <a
                        href={activeProjectModal.liveUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="w-full justify-center py-3 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold flex items-center gap-2 transition-colors"
                      >
                        <span>Launch Project</span>
                        <ExternalLink size={12} />
                      </a>
                      <a
                        href={activeProjectModal.githubUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="w-full justify-center py-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center gap-2 transition-colors border border-slate-200/30 dark:border-slate-700/30"
                      >
                        <Github size={14} />
                        <span>View Source Code</span>
                      </a>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
