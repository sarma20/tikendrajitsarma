import { motion } from 'motion/react';
import { Target, Smile, GraduationCap, Award, BookOpen } from 'lucide-react';
import { PERSONAL_INFO, FUN_FACTS, EDUCATION_HISTORY } from '../data';

export default function About() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: 'spring', stiffness: 100, damping: 15 },
    },
  };

  return (
    <section 
      id="about" 
      className="py-24 px-6 relative overflow-hidden bg-slate-50/50 dark:bg-slate-900/35 border-y border-slate-100 dark:border-slate-800/50"
    >
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-16">
          <h2 className="font-mono text-xs font-semibold tracking-widest text-violet-600 dark:text-violet-400 uppercase mb-3">
            01 / About Me
          </h2>
          <p className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white">
            Merging logic with creative artistry
          </p>
          <div className="w-12 h-[2px] bg-gradient-to-r from-violet-600 to-blue-500 mt-4 rounded-full" />
        </div>

        {/* Grid Content */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start"
        >
          {/* Left: Bio, Story and Objective (7 columns) */}
          <div className="lg:col-span-7 flex flex-col gap-8">
            {/* Story Card */}
            <motion.div 
              variants={itemVariants}
              className="glass-card p-8 rounded-3xl"
            >
              <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                <BookOpen size={18} className="text-violet-500" />
                <span>My Journey</span>
              </h3>
              <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed mb-4">
                {PERSONAL_INFO.story}
              </p>
              <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                As a developer, I believe true quality isn't just about writing code that compiles. It's about optimizing bundle sizes, creating layout structures that are inclusive, and ensuring page paint timings are near-instant. I constant push myself to refine every single visual and structural detail.
              </p>
            </motion.div>

            {/* Career Objective Card */}
            <motion.div 
              variants={itemVariants}
              className="glass-card p-8 rounded-3xl border-l-4 border-l-violet-600"
            >
              <h4 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                <Target size={18} className="text-violet-500" />
                <span>Career Objective</span>
              </h4>
              <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed font-sans italic">
                "{PERSONAL_INFO.objective}"
              </p>
            </motion.div>
          </div>

          {/* Right: Facts, Milestones and Stats (5 columns) */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            
            {/* Fun Facts Module */}
            <motion.div 
              variants={itemVariants}
              className="glass-card p-8 rounded-3xl"
            >
              <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                <Smile size={18} className="text-violet-500" />
                <span>Quick Trivia</span>
              </h3>
              
              <div className="flex flex-col gap-4">
                {FUN_FACTS.map((fact, idx) => (
                  <motion.div
                    key={idx}
                    whileHover={{ x: 6 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                    className="p-3.5 rounded-2xl bg-white/50 dark:bg-slate-800/40 border border-slate-200/40 dark:border-slate-700/30 text-slate-600 dark:text-slate-300 text-xs flex items-start gap-3"
                  >
                    <span className="text-sm shrink-0 leading-none">{fact.slice(0, 2)}</span>
                    <span className="leading-relaxed">{fact.slice(2)}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Quick Education snippet */}
            <motion.div 
              variants={itemVariants}
              className="glass-card p-8 rounded-3xl bg-gradient-to-br from-violet-500/5 to-blue-500/5"
            >
              <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                <GraduationCap size={18} className="text-violet-500" />
                <span>Background</span>
              </h3>
              
              <div className="flex flex-col gap-4">
                {EDUCATION_HISTORY.map((edu, idx) => (
                  <div key={edu.id} className="border-l border-slate-200 dark:border-slate-800 pl-4 relative">
                    <div className={`absolute -left-1.5 top-1.5 w-3 h-3 rounded-full ${idx === 0 ? 'bg-violet-600' : idx === 1 ? 'bg-blue-500' : 'bg-emerald-500'}`} />
                    <p className="text-[10px] font-mono text-slate-400 dark:text-slate-500 mb-1">{edu.institution}</p>
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">{edu.degree}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
