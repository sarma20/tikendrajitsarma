import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Phone, MapPin, Send, CheckCircle, Github, Linkedin, Instagram, AlertCircle, MessageCircle } from 'lucide-react';
import { PERSONAL_INFO } from '../data';

interface FormState {
  name: string;
  email: string;
  subject: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  message?: string;
}

export default function Contact() {
  const [form, setForm] = useState<FormState>({ name: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    // Clear validation error on change
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};
    if (!form.name.trim()) newErrors.name = 'Full name is required';
    if (!form.email.trim()) {
      newErrors.email = 'Email address is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = 'Please provide a valid email format';
    }
    if (!form.message.trim()) newErrors.message = 'Please write a message';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);

    // Simulate standard server API transmission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      setForm({ name: '', email: '', subject: '', message: '' });
    }, 1800);
  };

  return (
    <section 
      id="contact" 
      className="py-24 px-6 relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-16">
          <h2 className="font-mono text-xs font-semibold tracking-widest text-violet-600 dark:text-violet-400 uppercase mb-3">
            07 / Connection Channels
          </h2>
          <p className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white">
            Let's build something exceptional
          </p>
          <div className="w-12 h-[2px] bg-gradient-to-r from-violet-600 to-blue-500 mt-4 rounded-full" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Left: Contact Info & Social Connections */}
          <div className="lg:col-span-5 flex flex-col justify-between gap-10">
            <div className="flex flex-col gap-6">
              <h3 className="font-display text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                Direct Inquiries
              </h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed max-w-sm">
                Have an innovative project idea, looking to fill a roles opening, or just want to chat? Reach out directly or fill the secure form!
              </p>

              {/* Contact Detail Blocks */}
              <div className="flex flex-col gap-4 mt-2">
                <a 
                  href={`mailto:${PERSONAL_INFO.email}`}
                  className="group flex items-center gap-4 p-4 rounded-2xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/40 dark:hover:bg-slate-800 border border-slate-200/35 dark:border-slate-700/30 transition-all cursor-pointer"
                >
                  <div className="p-3 rounded-xl bg-violet-500/10 text-violet-600 dark:text-violet-400 group-hover:scale-105 transition-transform">
                    <Mail size={16} />
                  </div>
                  <div>
                    <span className="text-[9px] font-mono uppercase tracking-wider text-slate-400">Email Me</span>
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 break-all">{PERSONAL_INFO.email}</p>
                  </div>
                </a>

                <a 
                  href={`tel:${PERSONAL_INFO.phone}`}
                  className="group flex items-center gap-4 p-4 rounded-2xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/40 dark:hover:bg-slate-800 border border-slate-200/35 dark:border-slate-700/30 transition-all cursor-pointer"
                >
                  <div className="p-3 rounded-xl bg-violet-500/10 text-violet-600 dark:text-violet-400 group-hover:scale-105 transition-transform">
                    <Phone size={16} />
                  </div>
                  <div>
                    <span className="text-[9px] font-mono uppercase tracking-wider text-slate-400">Call Me</span>
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">{PERSONAL_INFO.phone}</p>
                  </div>
                </a>

                <a 
                  href={PERSONAL_INFO.whatsappUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="group flex items-center gap-4 p-4 rounded-2xl bg-emerald-50/50 hover:bg-emerald-100/60 dark:bg-emerald-950/10 dark:hover:bg-emerald-950/20 border border-emerald-200/20 dark:border-emerald-800/20 transition-all cursor-pointer"
                >
                  <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 group-hover:scale-105 transition-transform">
                    <MessageCircle size={16} />
                  </div>
                  <div>
                    <span className="text-[9px] font-mono uppercase tracking-wider text-emerald-600 dark:text-emerald-400 font-semibold">Direct Chat</span>
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      Contact via WhatsApp
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    </p>
                  </div>
                </a>

                <div 
                  className="group flex items-center gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/35 dark:border-slate-700/30"
                >
                  <div className="p-3 rounded-xl bg-violet-500/10 text-violet-600 dark:text-violet-400">
                    <MapPin size={16} />
                  </div>
                  <div>
                    <span className="text-[9px] font-mono uppercase tracking-wider text-slate-400">Location</span>
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">{PERSONAL_INFO.location}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Social Grid */}
            <div>
              <h4 className="text-[10px] font-mono uppercase tracking-wider text-slate-400 mb-4">
                Global Footprint
              </h4>
              <div className="flex items-center gap-3">
                <a
                  href={PERSONAL_INFO.githubUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-2xl bg-slate-100 hover:bg-violet-500/10 text-slate-600 dark:text-slate-300 hover:text-violet-600 dark:bg-slate-800/60 dark:hover:bg-slate-800 transition-all cursor-pointer border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
                  aria-label="GitHub"
                >
                  <Github size={18} />
                </a>
                <a
                  href={PERSONAL_INFO.linkedinUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-2xl bg-slate-100 hover:bg-violet-500/10 text-slate-600 dark:text-slate-300 hover:text-violet-600 dark:bg-slate-800/60 dark:hover:bg-slate-800 transition-all cursor-pointer border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
                  aria-label="LinkedIn"
                >
                  <Linkedin size={18} />
                </a>
                <a
                  href={PERSONAL_INFO.instagramUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-2xl bg-slate-100 hover:bg-violet-500/10 text-slate-600 dark:text-slate-300 hover:text-violet-600 dark:bg-slate-800/60 dark:hover:bg-slate-800 transition-all cursor-pointer border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
                  aria-label="Instagram"
                >
                  <Instagram size={18} />
                </a>
              </div>
            </div>
          </div>

          {/* Right: Contact Form Card */}
          <div className="lg:col-span-7">
            <div className="glass-card p-8 sm:p-10 rounded-3xl h-full flex flex-col justify-center">
              
              <AnimatePresence mode="wait">
                {!submitSuccess ? (
                  <motion.form
                    key="contact-form"
                    initial={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onSubmit={handleSubmit}
                    className="flex flex-col gap-5"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      {/* Name input */}
                      <div className="flex flex-col gap-1.5">
                        <label htmlFor="name" className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                          Full Name *
                        </label>
                        <input
                          id="name"
                          type="text"
                          name="name"
                          value={form.name}
                          onChange={handleInputChange}
                          placeholder="John Doe"
                          className={`w-full px-4 py-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border text-xs focus:outline-none transition-all ${
                            errors.name 
                              ? 'border-red-400 focus:border-red-500' 
                              : 'border-slate-200/60 dark:border-slate-800 focus:border-violet-500'
                          } text-slate-800 dark:text-white`}
                        />
                        {errors.name && (
                          <div className="flex items-center gap-1 text-[10px] text-red-500 mt-1">
                            <AlertCircle size={10} />
                            <span>{errors.name}</span>
                          </div>
                        )}
                      </div>

                      {/* Email input */}
                      <div className="flex flex-col gap-1.5">
                        <label htmlFor="email" className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                          Email Address *
                        </label>
                        <input
                          id="email"
                          type="email"
                          name="email"
                          value={form.email}
                          onChange={handleInputChange}
                          placeholder="john@example.com"
                          className={`w-full px-4 py-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border text-xs focus:outline-none transition-all ${
                            errors.email 
                              ? 'border-red-400 focus:border-red-500' 
                              : 'border-slate-200/60 dark:border-slate-800 focus:border-violet-500'
                          } text-slate-800 dark:text-white`}
                        />
                        {errors.email && (
                          <div className="flex items-center gap-1 text-[10px] text-red-500 mt-1">
                            <AlertCircle size={10} />
                            <span>{errors.email}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Subject input */}
                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="subject" className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                        Subject
                      </label>
                      <input
                        id="subject"
                        type="text"
                        name="subject"
                        value={form.subject}
                        onChange={handleInputChange}
                        placeholder="Collaboration Opportunities"
                        className="w-full px-4 py-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-800 focus:border-violet-500 text-xs focus:outline-none transition-all text-slate-800 dark:text-white"
                      />
                    </div>

                    {/* Message input */}
                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="message" className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                        Your Message *
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        rows={5}
                        value={form.message}
                        onChange={handleInputChange}
                        placeholder="Hi, I'd love to connect with you about..."
                        className={`w-full px-4 py-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border text-xs focus:outline-none transition-all resize-none ${
                          errors.message 
                            ? 'border-red-400 focus:border-red-500' 
                            : 'border-slate-200/60 dark:border-slate-800 focus:border-violet-500'
                        } text-slate-800 dark:text-white`}
                      />
                      {errors.message && (
                        <div className="flex items-center gap-1 text-[10px] text-red-500 mt-1">
                          <AlertCircle size={10} />
                          <span>{errors.message}</span>
                        </div>
                      )}
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="group w-full py-4 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold tracking-wide flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-slate-900/10 disabled:opacity-75 disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-violet-600 border-t-transparent rounded-full animate-spin" />
                          <span>Transmitting Secure Message...</span>
                        </>
                      ) : (
                        <>
                          <span>Send Message</span>
                          <Send size={12} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                        </>
                      )}
                    </button>
                  </motion.form>
                ) : (
                  <motion.div
                    key="success-prompt"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex flex-col items-center justify-center text-center p-6"
                  >
                    <div className="p-4 rounded-full bg-emerald-500/10 text-emerald-500 mb-6 animate-bounce">
                      <CheckCircle size={40} />
                    </div>
                    <h3 className="font-display text-lg sm:text-xl font-bold text-slate-900 dark:text-white mb-2">
                      Message Sent Successfully!
                    </h3>
                    <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm max-w-sm mb-8 leading-relaxed">
                      Thank you for reaching out! I have received your transmission and will get back to you within 24 hours.
                    </p>
                    <button
                      onClick={() => setSubmitSuccess(false)}
                      className="px-6 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Send Another Message
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
