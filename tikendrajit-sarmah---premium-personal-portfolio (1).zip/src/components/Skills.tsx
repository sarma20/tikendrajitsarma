import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Code2, Palette, Sparkles, Cpu, Server, Terminal, GitMerge, 
  Cloud, Database, Layers, Zap, Flame, GitBranch, Box, 
  Globe, ExternalLink, Layout, Smartphone, Eye 
} from 'lucide-react';
import { SKILL_CATEGORIES } from '../data';

const IconMap: { [key: string]: React.ComponentType<{ size?: number; className?: string }> } = {
  ReactIcon: Code2,
  Code2,
  Palette,
  Sparkles,
  Cpu,
  Server,
  Terminal,
  GitMerge,
  Cloud,
  Database,
  Layers,
  Zap,
  Flame,
  GitBranch,
  Box,
  Globe,
  ExternalLink,
  Figma: Palette, // use Palette as visual fallback for Figma
  Layout,
  Smartphone,
  Eye
};

export default function Skills() {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', ...SKILL_CATEGORIES.map(cat => cat.title)];

  const filteredSkills = selectedCategory === 'All'
    ? SKILL_CATEGORIES.flatMap(cat => cat.skills)
    : SKILL_CATEGORIES.find(cat => cat.title === selectedCategory)?.skills || [];

  return (
    <section 
      id="skills" 
      className="py-24 px-6 relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-12">
          <h2 className="font-mono text-xs font-semibold tracking-widest text-violet-600 dark:text-violet-400 uppercase mb-3">
            02 / Skills & Core Competencies
          </h2>
          <p className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white">
            High-caliber technical stack
          </p>
          <div className="w-12 h-[2px] bg-gradient-to-r from-violet-600 to-blue-500 mt-4 rounded-full" />
        </div>

        {/* Category Filter Pills (Horizontal Scroll on Mobile) */}
        <div className="flex justify-center mb-16 overflow-x-auto pb-4 max-w-full px-4 scrollbar-none">
          <div className="flex items-center gap-1.5 bg-slate-100/50 dark:bg-slate-800/40 p-1 rounded-full border border-slate-200/40 dark:border-slate-800/40 backdrop-blur-sm shrink-0">
            {categories.map((category) => {
              const isSelected = selectedCategory === category;
              return (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`relative px-4 sm:px-5 py-2 rounded-full text-[11px] sm:text-xs font-medium tracking-wide transition-all duration-200 cursor-pointer ${
                    isSelected 
                      ? 'text-slate-900 dark:text-white font-semibold shadow-xs' 
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  {isSelected && (
                    <motion.span
                      layoutId="activeCategoryBackground"
                      className="absolute inset-0 bg-white dark:bg-slate-900 rounded-full border border-slate-200/50 dark:border-slate-800/50 shadow-sm"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{category}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dynamic Skills Grid with Layout Animations */}
        <motion.div 
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          <AnimatePresence mode="popLayout">
            {filteredSkills.map((skill, index) => {
              const DynamicIcon = IconMap[skill.iconName] || Code2;
              return (
                <motion.div
                  layout
                  initial={{ opacity: 0, scale: 0.95, y: 15 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9, y: -10 }}
                  transition={{ type: 'spring', stiffness: 350, damping: 25, delay: index * 0.03 }}
                  key={skill.name}
                  className="glass-card p-6 rounded-2xl flex flex-col justify-between group hover:shadow-lg dark:hover:shadow-slate-900/50 hover:border-violet-500/20 dark:hover:border-violet-500/10"
                >
                  {/* Skill Card Header */}
                  <div className="flex items-center gap-3.5 mb-5">
                    <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 group-hover:bg-gradient-to-br group-hover:from-violet-500/10 group-hover:to-blue-500/10 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-all duration-300">
                      <DynamicIcon size={18} />
                    </div>
                    <div>
                      <h4 className="text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">
                        {skill.name}
                      </h4>
                      <p className="text-[10px] font-mono text-slate-400 dark:text-slate-500">
                        {skill.level >= 90 ? 'Expert' : skill.level >= 80 ? 'Advanced' : 'Proficient'}
                      </p>
                    </div>
                  </div>

                  {/* Proficiency Slider / Bar */}
                  <div className="w-full">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500">Proficiency</span>
                      <span className="text-[10px] font-mono font-semibold text-slate-700 dark:text-slate-300">
                        {skill.level}%
                      </span>
                    </div>
                    {/* Outer Bar */}
                    <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800/80 rounded-full overflow-hidden">
                      {/* Inner Filled Bar */}
                      <motion.div
                        className="h-full bg-gradient-to-r from-violet-600 to-blue-500 rounded-full"
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1.2, ease: 'easeOut' }}
                      />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
