import React from 'react';
import { motion } from 'motion/react';
import { Laptop, Palette, Server, Zap, CheckCircle } from 'lucide-react';
import { SERVICES } from '../data';

const IconMap: { [key: string]: React.ComponentType<{ size?: number; className?: string }> } = {
  Laptop,
  Figma: Palette, // fallback to Palette
  Server,
  Zap
};

export default function Services() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: 'spring', stiffness: 100, damping: 15 },
    },
  };

  return (
    <section 
      id="services" 
      className="py-24 px-6 relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-16">
          <h2 className="font-mono text-xs font-semibold tracking-widest text-violet-600 dark:text-violet-400 uppercase mb-3">
            05 / Professional Services
          </h2>
          <p className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white">
            What I bring to the table
          </p>
          <div className="w-12 h-[2px] bg-gradient-to-r from-violet-600 to-blue-500 mt-4 rounded-full" />
        </div>

        {/* Services Grid */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          {SERVICES.map((service) => {
            const DynamicIcon = IconMap[service.iconName] || Laptop;
            return (
              <motion.div
                variants={itemVariants}
                key={service.id}
                className="group glass-card p-8 rounded-3xl flex flex-col justify-between hover:shadow-xl dark:hover:shadow-slate-950/40 hover:border-violet-500/25 dark:hover:border-violet-500/10 transition-all duration-300"
              >
                <div>
                  {/* Icon Block */}
                  <div className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 w-fit mb-6 group-hover:bg-gradient-to-br group-hover:from-violet-500/15 group-hover:to-blue-500/15 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-all duration-300">
                    <DynamicIcon size={24} />
                  </div>

                  {/* Core Content */}
                  <h3 className="font-display text-lg sm:text-xl font-bold text-slate-900 dark:text-white mb-3 group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">
                    {service.title}
                  </h3>
                  
                  <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed mb-8">
                    {service.description}
                  </p>
                </div>

                {/* Sub-features list */}
                <div className="border-t border-slate-100 dark:border-slate-800/60 pt-6">
                  <h4 className="text-[10px] font-mono uppercase tracking-wider text-slate-400 mb-4">
                    Delivered Capabilities:
                  </h4>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-slate-600 dark:text-slate-350 text-xs font-medium">
                        <CheckCircle size={13} className="text-violet-500 shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

      </div>
    </section>
  );
}
