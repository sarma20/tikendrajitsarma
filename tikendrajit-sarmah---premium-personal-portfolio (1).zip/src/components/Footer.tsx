import { ArrowUp, Github, Linkedin, Instagram } from 'lucide-react';
import { PERSONAL_INFO } from '../data';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-slate-100 dark:border-slate-800/50 py-12 px-6 relative overflow-hidden bg-white/40 dark:bg-slate-950/40 backdrop-blur-xs">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
        
        {/* Left side: branding & copyright */}
        <div className="flex flex-col items-center md:items-start gap-1">
          <p className="font-display text-sm font-bold text-slate-800 dark:text-white">
            Tikendrajit Sarmah
          </p>
          <p className="text-[10px] font-mono text-slate-400 dark:text-slate-500">
            © {currentYear} Tikendrajit. All rights reserved. Made in SF.
          </p>
        </div>

        {/* Center: Social Links */}
        <div className="flex items-center gap-4">
          <a
            href={PERSONAL_INFO.githubUrl}
            target="_blank"
            rel="noreferrer"
            className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-800 border border-slate-200/25 dark:border-slate-800/30 text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
            aria-label="GitHub"
          >
            <Github size={15} />
          </a>
          <a
            href={PERSONAL_INFO.linkedinUrl}
            target="_blank"
            rel="noreferrer"
            className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-800 border border-slate-200/25 dark:border-slate-800/30 text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
            aria-label="LinkedIn"
          >
            <Linkedin size={15} />
          </a>
          <a
            href={PERSONAL_INFO.instagramUrl}
            target="_blank"
            rel="noreferrer"
            className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-800 border border-slate-200/25 dark:border-slate-800/30 text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
            aria-label="Instagram"
          >
            <Instagram size={15} />
          </a>
        </div>

        {/* Right side: back to top */}
        <button
          onClick={scrollToTop}
          className="group flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-800 border border-slate-200/30 dark:border-slate-800 text-slate-500 dark:text-slate-400 text-[10px] font-mono uppercase tracking-widest transition-all cursor-pointer"
          aria-label="Scroll back to top"
        >
          <span>Top</span>
          <ArrowUp size={12} className="group-hover:-translate-y-0.5 transition-transform" />
        </button>

      </div>
    </footer>
  );
}
