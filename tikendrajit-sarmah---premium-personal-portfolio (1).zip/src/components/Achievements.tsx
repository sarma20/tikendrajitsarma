import React, { useEffect, useState, useRef } from 'react';
import { motion, useInView } from 'motion/react';
import { ACHIEVEMENTS } from '../data';

interface StatCounterProps {
  value: string;
  label: string;
  key?: React.Key;
}

function StatCounter({ value, label }: StatCounterProps) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });
  const [displayValue, setDisplayValue] = useState('0');

  useEffect(() => {
    if (!isInView) return;

    // Parse the numeric part and non-numeric suffixes (e.g. "30+" -> 30, "+")
    const numericPart = parseInt(value, 10);
    const suffix = value.replace(String(numericPart), '');

    if (isNaN(numericPart)) {
      setDisplayValue(value);
      return;
    }

    let start = 0;
    const duration = 1.8 * 1000; // 1.8 seconds animate duration
    const stepTime = 30; // 30ms step intervals
    const steps = duration / stepTime;
    const increment = numericPart / steps;

    const timer = setInterval(() => {
      start += increment;
      if (start >= numericPart) {
        setDisplayValue(value);
        clearInterval(timer);
      } else {
        setDisplayValue(Math.floor(start) + suffix);
      }
    }, stepTime);

    return () => clearInterval(timer);
  }, [isInView, value]);

  return (
    <div 
      ref={ref} 
      className="glass-card p-8 rounded-3xl flex flex-col items-center justify-center text-center relative overflow-hidden group hover:shadow-lg dark:hover:shadow-slate-950/40 hover:border-violet-500/25 dark:hover:border-violet-500/10"
    >
      {/* Background visual flair */}
      <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-violet-600/5 to-blue-500/5 rounded-bl-3xl group-hover:scale-110 transition-transform pointer-events-none" />

      <h3 className="font-display text-4xl sm:text-5xl font-extrabold tracking-tight bg-gradient-to-r from-violet-600 via-indigo-500 to-blue-500 bg-clip-text text-transparent mb-2">
        {displayValue}
      </h3>
      <p className="text-slate-500 dark:text-slate-400 text-xs font-mono uppercase tracking-widest">
        {label}
      </p>
    </div>
  );
}

export default function Achievements() {
  return (
    <section 
      id="achievements" 
      className="py-16 px-6 relative overflow-hidden bg-slate-50/50 dark:bg-slate-900/35 border-b border-slate-100 dark:border-slate-800/50"
    >
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {ACHIEVEMENTS.map((stat) => (
            <StatCounter 
              key={stat.id}
              value={stat.value}
              label={stat.label}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
