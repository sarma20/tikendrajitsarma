import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import ExperienceAndEducation from './components/ExperienceAndEducation';
import Achievements from './components/Achievements';
import Services from './components/Services';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import Cursor from './components/Cursor';
import BackgroundEffects from './components/BackgroundEffects';

export default function App() {
  const [loading, setLoading] = useState(true);

  // Simulated premium loading screen trigger
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1800);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      {/* Premium Loading Screen Overlay */}
      <AnimatePresence>
        {loading && (
          <motion.div
            key="preloader"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="fixed inset-0 bg-white dark:bg-slate-950 z-50 flex flex-col items-center justify-center gap-4"
          >
            {/* Spinning vector spinner */}
            <div className="relative flex items-center justify-center">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 1.5, ease: 'linear' }}
                className="w-16 h-16 rounded-full border-t-2 border-violet-600 border-r-2 border-r-transparent"
              />
              <span className="absolute font-mono text-[9px] font-bold text-violet-600 dark:text-violet-400">
                TS
              </span>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="flex flex-col items-center"
            >
              <h2 className="font-display text-sm font-bold tracking-widest text-slate-900 dark:text-white uppercase">
                Tikendrajit Sarmah
              </h2>
              <p className="font-mono text-[9px] text-slate-400 dark:text-slate-500 tracking-widest uppercase mt-1">
                Portfolio Core Engine
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Portfolio Layout Content */}
      <div className="relative min-h-screen font-sans bg-[#F8F9FA] dark:bg-slate-950 text-slate-800 dark:text-slate-100 selection:bg-violet-500/20 dark:selection:bg-violet-500/30">
        
        {/* Custom interactive accessories */}
        <Cursor />
        <BackgroundEffects />
        
        {/* Navigation */}
        <Navbar />

        {/* Content Structure */}
        <main className="relative z-10 w-full overflow-hidden">
          {/* Hero Section */}
          <Hero />
          
          {/* Achievements row */}
          <Achievements />

          {/* About Section */}
          <About />

          {/* Skills Section */}
          <Skills />

          {/* Featured Projects Grid */}
          <Projects />

          {/* Work Experience & Academics timeline */}
          <ExperienceAndEducation />

          {/* Professional Services */}
          <Services />

          {/* Slider Testimonials */}
          <Testimonials />

          {/* Validated Contact Form */}
          <Contact />
        </main>

        {/* Minimal Footer */}
        <Footer />
      </div>
    </>
  );
}
